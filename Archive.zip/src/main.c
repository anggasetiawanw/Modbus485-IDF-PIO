#include "string.h"
#include "esp_log.h"
#include "mbcontroller.h"
#include "sdkconfig.h"

#define MB_PORT_NUM UART_NUM_2 // Number of UART port used for Modbus connection
#define MB_DEV_SPEED 9600      // The communication speed of the UART
#define U2RXD 16
#define U2TXD 17

// Note: Some pins on target chip cannot be assigned for UART communication.
// See UART documentation for selected board and target to configure pins using Kconfig.

#define STR(fieldname) ((const char *)(fieldname))
// Options can be used as bit masks or parameter limits
#define OPTS(min_val, max_val, step_val)                   \
    {                                                      \
        .opt1 = min_val, .opt2 = max_val, .opt3 = step_val \
    }

static const char *TAG = "MASTER_TEST";

// Enumeration of modbus device addresses accessed by master device
enum
{
    MB_DEVICE_ADDR1 = 0x01 // Only one slave device used for the test (add other slave addresses here)
};

// Enumeration of all supported CIDs for device (used in parameter definition table)
enum
{
    CID_VOLTAGE = 0,
    CID_CURRENT,
    CID_POWER,
    CID_FREQ,
    CID_THD_V,
    CID_THD_A
};
mb_parameter_descriptor_t device_parameters[] = {
    // CID, Name, Units, Modbus addr, register type, Modbus Reg Start Addr, Modbus Reg read length,
    // Instance offset (NA), Instance type, Instance length (bytes), Options (NA), Permissions
    {CID_VOLTAGE, STR("VOLTAGE"), STR("VOLTS"), MB_DEVICE_ADDR1, MB_PARAM_HOLDING, 0x0025, 6,
     0, PARAM_TYPE_U16, 12, OPTS(0, 9999, 1), PAR_PERMS_READ_WRITE_TRIGGER},
};
uint16_t num_device_parameters = (sizeof(device_parameters) / sizeof(device_parameters[0]));
// Modbus master initialization
static void master_operation_func(void *arg)
{
    const mb_parameter_descriptor_t *param_descriptor = NULL;
    uint8_t temp_data[12] = {0}; // temporary buffer to hold maximum CID size
    uint8_t type = 0;
    uint8_t cid = 0;

    ESP_LOGI(TAG, "Start modbus test...");
    esp_err_t err = mbc_master_get_cid_info(cid, &param_descriptor);
    if ((err != ESP_ERR_NOT_FOUND) && (param_descriptor != NULL))
    {
        err = mbc_master_get_parameter(param_descriptor->cid, (char *)param_descriptor->param_key, (uint8_t *)temp_data, &type);
        if (err == ESP_OK)
        {
            ESP_LOGI(TAG, "Characteristic #%d %s (%s) value = (0x%08x) read successful.",
                     param_descriptor->cid,
                     (char *)param_descriptor->param_key,
                     (char *)param_descriptor->param_units,
                     *(uint32_t *)temp_data);
                     for(uint8_t i =0;i<12;i++)
                     {
                        ESP_LOGI(TAG,"Value 1 Byte : %d", temp_data[i]);
                     }

            ESP_LOGI(TAG, "Voltage A-N %d", *(uint32_t *)temp_data);
        }
        else
        {
            ESP_LOGE(TAG, "Characteristic #%d (%s) read fail, err = 0x%x (%s).",
                     param_descriptor->cid,
                     (char *)param_descriptor->param_key,
                     (int)err,
                     (char *)esp_err_to_name(err));
        }
    }
    else
    {
        ESP_LOGE(TAG, "Could not get information for characteristic %d.", cid);
    }
}

static esp_err_t master_init(void)
{
    mb_communication_info_t comm = {
        .port = MB_PORT_NUM,
        .mode = MB_MODE_RTU,
        .baudrate = MB_DEV_SPEED,
        .parity = MB_PARITY_NONE};
    void *master_handler = NULL;
    esp_err_t err = mbc_master_init(MB_PORT_SERIAL_MASTER, &master_handler);
    MB_RETURN_ON_FALSE((master_handler != NULL), ESP_ERR_INVALID_STATE, TAG,
                       "mb controller initialization fail.");
    MB_RETURN_ON_FALSE((err == ESP_OK), ESP_ERR_INVALID_STATE, TAG,
                       "mb controller initialization fail, returns(0x%x).",
                       (uint32_t)err);
    err = mbc_master_setup((void *)&comm);
    MB_RETURN_ON_FALSE((err == ESP_OK), ESP_ERR_INVALID_STATE, TAG,
                       "mb controller setup fail, returns(0x%x).",
                       (uint32_t)err);
    err = uart_set_pin(MB_PORT_NUM, U2TXD, U2RXD,
                       UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE);
    err = mbc_master_start();
    MB_RETURN_ON_FALSE((err == ESP_OK), ESP_ERR_INVALID_STATE, TAG,
                       "mb controller start fail, returns(0x%x).",
                       (uint32_t)err);
    err = uart_set_mode(MB_PORT_NUM, UART_MODE_RS485_HALF_DUPLEX);
    MB_RETURN_ON_FALSE((err == ESP_OK), ESP_ERR_INVALID_STATE, TAG,
                       "mb serial set mode failure, uart_set_mode() returned (0x%x).", (uint32_t)err);
    vTaskDelay(5);
    err = mbc_master_set_descriptor(&device_parameters[0], num_device_parameters);
    MB_RETURN_ON_FALSE((err == ESP_OK), ESP_ERR_INVALID_STATE, TAG,
                       "mb controller set descriptor fail, returns(0x%x).",
                       (uint32_t)err);
    ESP_LOGI(TAG, "Modbus master stack initialized...");

    return err;
}

void app_main(void)
{
    vTaskDelay(1000);
    ESP_ERROR_CHECK(master_init());
    vTaskDelay(10);
    master_operation_func(NULL);
}